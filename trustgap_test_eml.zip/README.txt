SYNTHETIC test emails for TrustGap A1 (Sublime EML Analyzer). Fictional domains/addresses; no real data.
Expected labels: 01,02,09 benign; 03-06,08 malicious lookalike/BEC/phish; 07 suspicious; 10 spoof (auth fail).
